# LWG Partners Network E-Commerce Project

This project contains both the **frontend** (static site) and the **backend** (Node.js API).

## Structure
